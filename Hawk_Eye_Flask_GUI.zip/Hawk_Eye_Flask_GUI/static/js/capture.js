document.getElementById("div_captured").style.display="none";

function ShowCam() {
  Webcam.set({
      width: 480,
      height: 320,
      image_format: 'jpeg',
      jpeg_quality: 100
  });
  Webcam.attach('#my_camera');
}
window.onload= ShowCam;

function snap() {
  Webcam.snap( function(data_uri) {
      // display results in page
      document.getElementById('results').innerHTML =
      '<img id="image" width="440" height="320" src="'+data_uri+'"/>';

      document.getElementById("div_captured").style.display="block";
    } );
}
function upload() {
  console.log("Uploading...")
  alert('Compiling Results...Please wait for few seconds')
  var image = document.getElementById('image').src;
  var form = document.getElementById('myForm');
  var formData = new FormData(form);
  formData.append("file", image);
  var xmlhttp = new XMLHttpRequest();
  var path = window.location.pathname;
  page = path.split("/")[1]

  xmlhttp.open("POST", "/"+page+"/capture_image");

  xmlhttp.send(formData);

  // check when state changes,
  xmlhttp.onreadystatechange = function() {

  if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      window.location = "/"+page+"/result"
      }
  }

}
